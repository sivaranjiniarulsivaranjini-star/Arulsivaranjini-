import express from "express";
import dotenv from "dotenv";
import { GoogleGenerativeAI } from "@google/generative-ai";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

function demoComic(idea, genre, panels) {
  const safeIdea = idea.trim() || "A mysterious adventure";
  const count = Math.min(Math.max(Number(panels) || 6, 3), 12);

  const panelList = Array.from({ length: count }, (_, i) => ({
    panel: i + 1,
    scene: i === 0
      ? `Opening shot introducing the world of "${safeIdea}".`
      : i === count - 1
        ? "The conflict resolves with a memorable final image and a hook for another adventure."
        : `The characters face a new ${genre.toLowerCase()} challenge connected to the main idea.`,
    narration: i % 2 === 0 ? "Something unexpected is about to change everything." : "",
    dialogue: i % 2 === 0
      ? `"We have to keep going!"`
      : `"There must be another way."`,
    visual: "Dynamic comic-book composition, expressive characters, clear foreground and background."
  }));

  return {
    title: `${genre} Chronicles: ${safeIdea.slice(0, 35)}`,
    logline: `A ${genre.toLowerCase()} adventure inspired by ${safeIdea}.`,
    characters: [
      { name: "Maya", role: "Protagonist", description: "Curious, brave, and determined to solve the mystery." },
      { name: "Ravi", role: "Companion", description: "A clever friend who brings humor and practical ideas." },
      { name: "The Shadow", role: "Antagonist", description: "A mysterious force that tests the heroes." }
    ],
    panels: panelList
  };
}

function extractJson(text) {
  const cleaned = text.replace(/```json/gi, "").replace(/```/g, "").trim();
  try { return JSON.parse(cleaned); } catch {}
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start >= 0 && end > start) {
    return JSON.parse(cleaned.slice(start, end + 1));
  }
  throw new Error("Gemini returned an invalid JSON response.");
}

app.post("/api/generate", async (req, res) => {
  try {
    const { idea, genre = "Adventure", panels = 6 } = req.body || {};

    if (!idea || idea.trim().length < 3) {
      return res.status(400).json({ error: "Please enter a story idea." });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.json({
        mode: "demo",
        comic: demoComic(idea, genre, panels)
      });
    }

    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    const model = genAI.getGenerativeModel({
      model: process.env.GEMINI_MODEL || "gemini-2.0-flash"
    });

    const prompt = `You are ComicCraft AI, an expert comic story writer.
Create an original comic story from the user's idea.

User idea: ${idea}
Genre: ${genre}
Number of panels: ${panels}

Return ONLY valid JSON with this exact shape:
{
  "title": "string",
  "logline": "string",
  "characters": [
    {"name":"string","role":"string","description":"string"}
  ],
  "panels": [
    {
      "panel": 1,
      "scene": "string",
      "narration": "string",
      "dialogue": "string",
      "visual": "string"
    }
  ]
}

Rules:
- Create 3 to 5 characters.
- Use exactly ${Math.min(Math.max(Number(panels) || 6, 3), 12)} panels.
- Make the story coherent with a beginning, conflict, escalation and ending.
- Keep dialogue concise enough for a comic speech bubble.
- Make visual descriptions useful for a future image-generation step.
- Do not include markdown or commentary outside the JSON.`;

    const result = await model.generateContent(prompt);
    const text = result.response.text();
    const comic = extractJson(text);

    res.json({ mode: "gemini", comic });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "Comic generation failed.",
      details: error.message
    });
  }
});

app.get("*", (_, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`ComicCraft AI running at http://localhost:${PORT}`);
});
