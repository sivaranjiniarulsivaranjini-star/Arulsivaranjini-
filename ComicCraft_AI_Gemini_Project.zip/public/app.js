const form = document.getElementById("comicForm");
const btn = document.getElementById("generateBtn");
const status = document.getElementById("status");
const result = document.getElementById("result");

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  btn.disabled = true;
  status.textContent = "Creating your comic...";
  result.classList.add("hidden");

  const payload = {
    idea: document.getElementById("idea").value,
    genre: document.getElementById("genre").value,
    panels: Number(document.getElementById("panels").value)
  };

  try {
    const response = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Generation failed");
    renderComic(data.comic);
    status.textContent = data.mode === "demo"
      ? "Demo story generated. Add a Gemini API key for live AI generation."
      : "Comic generated with Gemini.";
  } catch (err) {
    status.textContent = err.message;
  } finally {
    btn.disabled = false;
  }
});

function renderComic(comic) {
  document.getElementById("title").textContent = comic.title;
  document.getElementById("logline").textContent = comic.logline;

  document.getElementById("characters").innerHTML = comic.characters.map(c => `
    <article class="character">
      <h4>${escapeHtml(c.name)}</h4>
      <strong>${escapeHtml(c.role)}</strong>
      <p>${escapeHtml(c.description)}</p>
    </article>
  `).join("");

  document.getElementById("panelsOutput").innerHTML = comic.panels.map(p => `
    <article class="panel">
      <div class="panel-number">PANEL ${p.panel}</div>
      <h4>${escapeHtml(p.scene)}</h4>
      <p><strong>Visual:</strong> ${escapeHtml(p.visual)}</p>
      ${p.narration ? `<p><strong>Narration:</strong> ${escapeHtml(p.narration)}</p>` : ""}
      ${p.dialogue ? `<p><strong>Dialogue:</strong> ${escapeHtml(p.dialogue)}</p>` : ""}
    </article>
  `).join("");

  result.classList.remove("hidden");
  result.scrollIntoView({ behavior: "smooth" });
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[ch]));
}

document.getElementById("printBtn").addEventListener("click", () => window.print());
